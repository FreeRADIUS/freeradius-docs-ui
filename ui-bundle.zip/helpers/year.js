'use strict'

module.exports = () => new Date().getFullYear().toString()
